// Sample JS code
// window.addEventListener('load', (ev) => {
//     alert('Welcome to this PHP website!');
// });