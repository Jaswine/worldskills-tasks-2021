<?php
use yii\helpers\Html;

/** @var string $message */
$message;
?>
<?= Html::encode($message) ?>
