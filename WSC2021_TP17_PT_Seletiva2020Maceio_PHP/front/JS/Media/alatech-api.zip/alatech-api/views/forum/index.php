<?php
?>
<html>
<head>
    <title>Pesado esse módulo, hein!</title>
</head>
<body>
<h1>H<span style="font-weight: bold; color: red">a</span>llo, controller!</h1>
<h2>Bye, controller!</h2>
</body>
</html>
